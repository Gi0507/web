export class Pedido {}
